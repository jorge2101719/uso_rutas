<template>
    <div>
        <h1>Página de contacto</h1>
        <p>Dirección</p>
        <p>Teléfono</p>
        <p>Dirección</p>
    </div>
</template>