<template>
    <div>
        <h1>Sobre mí</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem modi et in possimus ducimus neque exercitationem quas esse mollitia. Nemo quidem quos error obcaecati facere corrupti optio eum qui facilis?</p>
    </div>
</template>