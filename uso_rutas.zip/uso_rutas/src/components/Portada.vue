<template>
    <div>
        <h1>Portada</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur rem dolore porro quaerat officia deserunt eaque exercitationem eum eveniet id? Doloribus, modi necessitatibus! Doloremque vero perferendis, consequuntur velit perspiciatis quod.</p>
    </div>
</template>