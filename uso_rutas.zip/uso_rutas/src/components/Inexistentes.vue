<template>
    <div>
        <h1>
            Lo que busca no está aquí...
        </h1>
        <router-link to="/inexistente"></router-link>
    </div>
</template>