<template>
    <div>
        <h1 v-text="tituloPost"></h1>
        <router-link>Anterior</router-link>
        <router-link >Siguiente</router-link>
        <p></p>
        <router-link :to="{name: 'comentarios'}">Ver comentarios</router-link>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    methods: {
        paginar(siguiente) {
            let entrada = parseInt(this.$route.params.entrada);
            if(siguiente) {
                return entrada < 3 ? `/post/${entrada + 1}` : `/post/${entrada}`
            } else {
                return entrada > 1 ? `/post/${entrada - 1}` : `/post/${entrada}`
            }
        }
    },
    computed: {
        tituloPost() {
            return `Post ${this.$route.params.entrada} del sitio... `
        }
    }
}
</script>