import Vue from 'vue';
import Router from 'vue-router';

import Portada from './components/Portada';
import Sobremi from './components/Sobremi';
import Contacto from './components/Contacto';
import Comentarios from './components/Comentarios';
import Post from './components/Post'
import Inexistentes from './components/Inexistentes'

Vue.use(Router)

export default new Router({
    mode: 'history',
    routes: [
        {
            path: '/',
            component: Portada,
        },
        {
            path: '/contacto',
            component: Contacto
        }, 
        {
            path: '/sobremi',
            component: Sobremi
        }, 
        {
            path: '/post/:entrada',
            component: Post,
            children: [
                {
                    path: 'comentarios',
                    component: Comentarios,
                    name: 'comentarios'
                }
            ]
        }, 
        {
            path: '*',
            component: Inexistentes
        }, 
    ]
})